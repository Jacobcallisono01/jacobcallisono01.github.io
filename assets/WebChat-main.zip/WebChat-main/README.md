# WebChat

A simple web chatting app using Socket.io, Node.js, MongoDB.

## Install Dependencies
```bash
npm install 
```

## Run Server
```bash
npm start
```
